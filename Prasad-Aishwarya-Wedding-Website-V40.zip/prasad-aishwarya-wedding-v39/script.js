const CONFIG={weddingDate:"2026-11-29T08:00:00+05:30",googleMapsUrl:"https://www.google.com/maps/place/Millenium+Garden+Belagavi/data=!4m2!3m1!1s0x0:0xf6407e9e3d2933a4?sa=X&ved=1t:2428&ictx=111",rsvpWhatsApp:"9900103147"};
const events={
engagement:{title:"Engagement",type:"A BEGINNING OF A BEAUTIFUL FOREVER",subtitle:"A beginning of a beautiful forever.",date:"28 NOVEMBER 2026",dateLong:"Saturday, 28 November 2026",time:"6:30 PM",start:"20261128T183000",image:"./assets/event-engagement.jpg",theme:"Blush Garden Romance",colors:"Blush Pink · Ivory · Champagne Gold",dress:"Elegant & Festive"},
sangeet:{title:"Sangeet",type:"AN EVENING OF MUSIC, JOY & CELEBRATION",subtitle:"An evening of music, joy and celebration.",date:"28 NOVEMBER 2026",dateLong:"Saturday, 28 November 2026",time:"8:30 PM",start:"20261128T203000",image:"./assets/event-sangeet.jpg",theme:"Royal Musical Night",colors:"Wine · Plum · Antique Gold",dress:"Glamorous & Festive"},
haldi:{title:"Haldi",type:"A SPLASH OF LOVE, COLOUR & NEW BEGINNINGS",subtitle:"A splash of love, colour and new beginnings.",date:"28 NOVEMBER 2026",dateLong:"Saturday, 28 November 2026",time:"10:00 PM",start:"20261128T220000",image:"./assets/event-haldi.jpg",theme:"Marigold Sunshine",colors:"Yellow · Marigold · Orange · Cream",dress:"Bright & Traditional"},
muhurta:{title:"Muhurta",type:"THE SACRED MOMENT WE BECOME ONE",subtitle:"The sacred moment we become one.",date:"29 NOVEMBER 2026",dateLong:"Sunday, 29 November 2026",time:"8:00 AM",start:"20261129T080000",image:"./assets/event-muhurta.jpg",theme:"Sacred Traditional Elegance",colors:"Ivory · Gold · Sage Green",dress:"Traditional Indian"},
reception:{title:"Reception",type:"AN AFTERNOON OF LOVE, LAUGHTER & TOGETHERNESS",subtitle:"An afternoon of love, laughter and togetherness.",date:"29 NOVEMBER 2026",dateLong:"Sunday, 29 November 2026",time:"12:25 PM",start:"20261129T122500",image:"./assets/event-reception.jpg",theme:"Daytime Garden Celebration",colors:"Peach · Ivory · Sage Green · Champagne",dress:"Elegant & Day Festive"}
};
window.addEventListener("load",()=>setTimeout(()=>document.getElementById("loader").classList.add("hide"),900));document.getElementById("beginBtn").onclick=()=>document.getElementById("welcome").scrollIntoView({behavior:"smooth"});const menu=document.getElementById("menu");document.getElementById("menuBtn").onclick=()=>menu.classList.add("open");document.getElementById("menuClose").onclick=()=>menu.classList.remove("open");document.querySelectorAll(".menu a").forEach(a=>a.onclick=()=>menu.classList.remove("open"));function countdown(){const diff=new Date(CONFIG.weddingDate)-new Date(),v=diff<=0?[0,0,0,0]:[Math.floor(diff/86400000),Math.floor(diff/3600000)%24,Math.floor(diff/60000)%60,Math.floor(diff/1000)%60];["d","h","m","s"].forEach((id,i)=>document.getElementById(id).textContent=String(v[i]).padStart(2,"0"))}countdown();setInterval(countdown,1000);const modal=document.getElementById("modal");function openEvent(key){
  const e=events[key];
  document.getElementById("inviteCard").className = `invite-card event-${key}`;
  modal.style.setProperty("--event-image", `url("${e.image}")`);
  document.getElementById("modalTitle").textContent=e.title;
  document.getElementById("modalType").textContent=e.type;
  document.getElementById("modalSubtitle").textContent=e.subtitle;
  document.getElementById("modalDateLong").textContent=e.dateLong;
  document.getElementById("modalTime").textContent=e.time;
  document.getElementById("modalTheme").textContent=e.theme;
  document.getElementById("modalColors").textContent=e.colors;
  document.getElementById("modalDress").textContent=e.dress;
  document.getElementById("modalMaps").onclick=()=>window.open(CONFIG.googleMapsUrl,"_blank");
  document.getElementById("modalCalendar").onclick=()=>downloadCalendar(key);
  modal.classList.add("show");
  document.body.style.overflow="hidden";
}document.querySelectorAll(".event-card").forEach(x=>x.onclick=()=>openEvent(x.dataset.event));function downloadCalendar(key){
  const e = events[key];
  const [Y,M,D,h,m,s] = e.start.match(/(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})/).slice(1).map(Number);

  const start = new Date(Y, M-1, D, h, m, s);
  const end = new Date(start.getTime() + 60*60*1000);
  const pad = n => String(n).padStart(2,"0");

  const localStamp = d =>
    `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;

  const esc = value =>
    String(value)
      .replace(/\\/g,"\\\\")
      .replace(/;/g,"\\;")
      .replace(/,/g,"\\,")
      .replace(/\r?\n/g,"\\n");

  const uid = `${key}-prasad-aishwarya-2026@wedding`;
  const dtstamp = new Date().toISOString().replace(/[-:]/g,"").replace(/\.\d{3}Z$/,"Z");
  const location = "Millennium Gardens, Belagavi, Karnataka, India";
  const description = `${e.subtitle}\\n\\nTheme: ${e.theme}\\nMain colors: ${e.colors}\\nDress code: ${e.dress}\\n\\nGoogle Maps: ${CONFIG.googleMapsUrl}`;

  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Prasad & Aishwarya//Wedding Invitation//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART;TZID=Asia/Kolkata:${localStamp(start)}`,
    `DTEND;TZID=Asia/Kolkata:${localStamp(end)}`,
    `SUMMARY:${esc(e.title + " — Prasad & Aishwarya")}`,
    `LOCATION:${esc(location)}`,
    `DESCRIPTION:${esc(description)}`,
    `URL:${CONFIG.googleMapsUrl}`,
    "STATUS:CONFIRMED",
    "TRANSP:OPAQUE",
    "BEGIN:VALARM",
    "TRIGGER:-PT30M",
    "ACTION:DISPLAY",
    `DESCRIPTION:${esc(e.title + " starts in 30 minutes")}`,
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");

  const blob = new Blob([ics], {type:"text/calendar;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${key}-prasad-aishwarya-2026.ics`;
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function closeModal(){modal.classList.remove("show");document.body.style.overflow=""}document.getElementById("modalClose").onclick=closeModal;document.getElementById("modalBackdrop").onclick=closeModal;const audio=document.getElementById("audio"),music=document.getElementById("music");music.onclick=async()=>{try{if(audio.paused){await audio.play();music.textContent="❚❚"}else{audio.pause();music.textContent="♪"}}catch(e){alert("Add assets/wedding-music.mp3 if you want background music.")}};document.getElementById("rsvpForm").onsubmit=e=>{
 e.preventDefault();
 const name=document.getElementById("name").value.trim();
 const status=document.getElementById("status").value;
 const count=document.getElementById("count").value;
 const digits=CONFIG.rsvpWhatsApp.replace(/\\D/g,"");
 const message=encodeURIComponent(
   `Hello! This is ${name}.\n\nWedding RSVP — Prasad & Aishwarya\nResponse: ${status}\nNumber of guests: ${count}`
 );
 window.open(`https://wa.me/91${digits}?text=${message}`,"_blank");
 document.getElementById("rsvpMsg").textContent="Opening WhatsApp… Thank you for your response!";
};
const direct=document.getElementById("whatsappDirect");if(direct){const d=CONFIG.rsvpWhatsApp.replace(/\D/g,"");direct.href=`https://wa.me/91${d}?text=${encodeURIComponent("Hello! I would like to RSVP for Prasad & Aishwarya's wedding.")}`}document.getElementById("maps").onclick=e=>{e.preventDefault();window.open(CONFIG.googleMapsUrl,"_blank")};
document.addEventListener("keydown",e=>{
 if(e.key==="Escape" && modal.classList.contains("show")) closeModal();
});

audio.addEventListener("error",()=>{
  music.style.display="none";
});
audio.addEventListener("loadeddata",()=>{
  music.style.display="";
});
