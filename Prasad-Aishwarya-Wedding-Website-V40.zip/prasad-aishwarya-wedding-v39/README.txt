Prasad & Aishwarya Wedding Website V39

Mobile event cards have been rebuilt with a definitive fixed mobile layout:
- thumbnail has its own fixed position
- event text starts after the thumbnail and cannot overlap it
- event arrow has its own fixed position
- title, time, theme and dress code remain vertically aligned
- desktop layout remains unchanged
- all V38 assets and content are preserved
